BioEcho AI Simple Prototype

Three screens: Observe, Compare, Explain.
Uses simulated data for the hackathon proof of concept.